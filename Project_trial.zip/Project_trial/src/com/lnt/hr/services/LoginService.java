package com.lnt.hr.services;

import com.lnt.hr.entities.Login;
import com.lnt.hr.exception.LoginException;

public interface LoginService 
{
	public Login insertNewStudent(Login login) throws LoginException;
	public int loginCheck(Login login) throws LoginException;
	//public Login loginCheck(Login login) throws LoginException;

}