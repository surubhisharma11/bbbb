package com.lnt.hr.services;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.lnt.hr.daos.LoginDao;
import com.lnt.hr.entities.Login;
import com.lnt.hr.exception.LoginException;

@Service("LoginServiceImpl")
public class LoginServiceImpl implements LoginService
{
	@Autowired
	LoginDao loginDao;

	public Login insertNewStudent(Login login) throws LoginException 
	{
		return loginDao.insertNewStudent(login);
	}

	/*@Override
	public Login loginCheck(Login login) throws LoginException 
	{
		return loginDao.loginCheck(login);
	}*/

	@Override
	public int loginCheck(Login login) throws LoginException 
	{
		return loginDao.loginCheck(login);
	}
	

	

}