package com.lnt.hr.entities;


import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.springframework.format.annotation.DateTimeFormat;

@NamedQueries( { @NamedQuery(name="allStudent",query="from Scholarship"),
 @NamedQuery(name="allMinStudent",query=" from Scholarship where descriptionLevelTwo ='Approved'")
})
@Entity
@Table(name="SCHOLARSHIP")
public class Scholarship 
{
	
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator ="IDSCHOLARSHIP_SEQ")
	@SequenceGenerator(name = "IDSCHOLARSHIP_SEQ", sequenceName = "seq_scholarship", allocationSize = 1)
	@Id
	@Column(name="APPLICATIONID")
	private long applicationId;
	@Column(name="AADHAARNUMBER")
	private long aadhaarNumber;
	@Column(name="RELIGION")
	private String religion;
	@Column(name="COMMUNITY")
	private String community;
	@Column(name="FATHERNAME")
	private String fatherName;
	@Column(name="MOTHERNAME")
	private String motherName;
	@Column(name="FAMILYANNUALINCOME")
	private long familyAnnualIncome;
	@Column(name="RATIONCARDNUMBER")
	private long rationCardNumber;
	@Column(name="INSTITUTENAME")
	private String instituteName;
	@Column(name="PRESENTCOURSE")
	private String presentCourse;
	
	@Column(name="PRESENTCLASSYEAR")
	private String presentClassYear;
	@Column(name="MODEOFSTUDY")
	private String modeOfStudy;
	
	@Column(name="CLASSSTARTDATE")
	private String classStartDate;
	@Column(name="UNIVERSITYBOARDNAME")
	private String universityBoardName;
	@Column(name="PREVIOUSCLASSCOURSE")
	private String previousClassCourse;
	@Column(name="PREVIOUSPASSINGYEAR")
	private String previousPassingYear;
	@Column(name="PREVIOUSCLASSPERCENT")
	private int previousClassPercent;
	@Column(name="TENTHROLLNUMBER")
	private long tenthRollNumber;
	@Column(name="TENTHBOARDNAME")
	private String tenthBoardName;
	//@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column(name="TENTHPASSINGYEAR")
	private String tenthPassingYear;
	@Column(name="TENTHPERCENTOBTAINED")
	private int tenthPercentObtained; 
	@Column(name="TWELTHROLLNUMBER")
	private long twelthRollNumber;
	@Column(name="TWELTHBOARDNAME")
	private String twelthBoardName;
	//@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column(name="TWELTHPASSINGYEAR")
	private String twelthPassingYear;
	@Column(name="TWELTHPERCENTOBTAINED")
	private int twelthPercentObtained;
	@Column(name="ADMISSIONFEE")
	private int admissionFee;
	@Column(name="TUTIONFEE")
	private int tutionFee;
	@Column(name="OTHERFEE")
	private int otherFee;
	@Column(name="DISABILITY")
	private String disability;
	@Column(name="DISABILITYTYPE")
	private String disabilityType;
	@Column(name="PERCENTOFDISABILITY")
	private int percentOfDisability; 
	@Column(name="MARITALSTATUS")
	private String maritalStatus;
	@Column(name="PARENTSPROFESSION")
	private String parentsProfession;
	@Column(name="ADDRESS")
	private String address;
	@Column(name="SCHEME")
	private String scheme;
	@Column(name="STATUS")
	private String status;
	@Column(name="DESCRIPTIONLEVELONE")
	private String descriptionLevelOne;
	@Column(name="DESCRIPTIONLEVELTWO")
	private String descriptionLevelTwo;
	@Column(name="DESCRIPTIONLEVELTHREE")
	private String descriptionLevelThree;
	
	public Scholarship() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Scholarship(long applicationId, long aadhaarNumber, String religion, String community, String fatherName,
			String motherName, long familyAnnualIncome, long rationCardNumber, String instituteName,
			String presentCourse, String presentClassYear, String modeOfStudy, String classStartDate,
			String universityBoardName, String previousClassCourse, String previousPassingYear,
			int previousClassPercent, long tenthRollNumber, String tenthBoardName, String tenthPassingYear,
			int tenthPercentObtained, long twelthRollNumber, String twelthBoardName, String twelthPassingYear,
			int twelthPercentObtained, int admissionFee, int tutionFee, int otherFee, String disability,
			String disabilityType, int percentOfDisability, String maritalStatus, String parentsProfession,
			String address, String scheme, String status, String descriptionLevelOne, String descriptionLevelTwo,
			String descriptionLevelThree) {
		super();
		this.applicationId = applicationId;
		this.aadhaarNumber = aadhaarNumber;
		this.religion = religion;
		this.community = community;
		this.fatherName = fatherName;
		this.motherName = motherName;
		this.familyAnnualIncome = familyAnnualIncome;
		this.rationCardNumber = rationCardNumber;
		this.instituteName = instituteName;
		this.presentCourse = presentCourse;
		this.presentClassYear = presentClassYear;
		this.modeOfStudy = modeOfStudy;
		this.classStartDate = classStartDate;
		this.universityBoardName = universityBoardName;
		this.previousClassCourse = previousClassCourse;
		this.previousPassingYear = previousPassingYear;
		this.previousClassPercent = previousClassPercent;
		this.tenthRollNumber = tenthRollNumber;
		this.tenthBoardName = tenthBoardName;
		this.tenthPassingYear = tenthPassingYear;
		this.tenthPercentObtained = tenthPercentObtained;
		this.twelthRollNumber = twelthRollNumber;
		this.twelthBoardName = twelthBoardName;
		this.twelthPassingYear = twelthPassingYear;
		this.twelthPercentObtained = twelthPercentObtained;
		this.admissionFee = admissionFee;
		this.tutionFee = tutionFee;
		this.otherFee = otherFee;
		this.disability = disability;
		this.disabilityType = disabilityType;
		this.percentOfDisability = percentOfDisability;
		this.maritalStatus = maritalStatus;
		this.parentsProfession = parentsProfession;
		this.address = address;
		this.scheme = scheme;
		this.status = status;
		this.descriptionLevelOne = descriptionLevelOne;
		this.descriptionLevelTwo = descriptionLevelTwo;
		this.descriptionLevelThree = descriptionLevelThree;
	}

	public long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	public long getAadhaarNumber() {
		return aadhaarNumber;
	}

	public void setAadhaarNumber(long aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getCommunity() {
		return community;
	}

	public void setCommunity(String community) {
		this.community = community;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public long getFamilyAnnualIncome() {
		return familyAnnualIncome;
	}

	public void setFamilyAnnualIncome(long familyAnnualIncome) {
		this.familyAnnualIncome = familyAnnualIncome;
	}

	public long getRationCardNumber() {
		return rationCardNumber;
	}

	public void setRationCardNumber(long rationCardNumber) {
		this.rationCardNumber = rationCardNumber;
	}

	public String getInstituteName() {
		return instituteName;
	}

	public void setInstituteName(String instituteName) {
		this.instituteName = instituteName;
	}

	public String getPresentCourse() {
		return presentCourse;
	}

	public void setPresentCourse(String presentCourse) {
		this.presentCourse = presentCourse;
	}

	public String getPresentClassYear() {
		return presentClassYear;
	}

	public void setPresentClassYear(String presentClassYear) {
		this.presentClassYear = presentClassYear;
	}

	public String getModeOfStudy() {
		return modeOfStudy;
	}

	public void setModeOfStudy(String modeOfStudy) {
		this.modeOfStudy = modeOfStudy;
	}

	public String getClassStartDate() {
		return classStartDate;
	}

	public void setClassStartDate(String classStartDate) {
		this.classStartDate = classStartDate;
	}

	public String getUniversityBoardName() {
		return universityBoardName;
	}

	public void setUniversityBoardName(String universityBoardName) {
		this.universityBoardName = universityBoardName;
	}

	public String getPreviousClassCourse() {
		return previousClassCourse;
	}

	public void setPreviousClassCourse(String previousClassCourse) {
		this.previousClassCourse = previousClassCourse;
	}

	public String getPreviousPassingYear() {
		return previousPassingYear;
	}

	public void setPreviousPassingYear(String previousPassingYear) {
		this.previousPassingYear = previousPassingYear;
	}

	public int getPreviousClassPercent() {
		return previousClassPercent;
	}

	public void setPreviousClassPercent(int previousClassPercent) {
		this.previousClassPercent = previousClassPercent;
	}

	public long getTenthRollNumber() {
		return tenthRollNumber;
	}

	public void setTenthRollNumber(long tenthRollNumber) {
		this.tenthRollNumber = tenthRollNumber;
	}

	public String getTenthBoardName() {
		return tenthBoardName;
	}

	public void setTenthBoardName(String tenthBoardName) {
		this.tenthBoardName = tenthBoardName;
	}

	public String getTenthPassingYear() {
		return tenthPassingYear;
	}

	public void setTenthPassingYear(String tenthPassingYear) {
		this.tenthPassingYear = tenthPassingYear;
	}

	public int getTenthPercentObtained() {
		return tenthPercentObtained;
	}

	public void setTenthPercentObtained(int tenthPercentObtained) {
		this.tenthPercentObtained = tenthPercentObtained;
	}

	public long getTwelthRollNumber() {
		return twelthRollNumber;
	}

	public void setTwelthRollNumber(long twelthRollNumber) {
		this.twelthRollNumber = twelthRollNumber;
	}

	public String getTwelthBoardName() {
		return twelthBoardName;
	}

	public void setTwelthBoardName(String twelthBoardName) {
		this.twelthBoardName = twelthBoardName;
	}

	public String getTwelthPassingYear() {
		return twelthPassingYear;
	}

	public void setTwelthPassingYear(String twelthPassingYear) {
		this.twelthPassingYear = twelthPassingYear;
	}

	public int getTwelthPercentObtained() {
		return twelthPercentObtained;
	}

	public void setTwelthPercentObtained(int twelthPercentObtained) {
		this.twelthPercentObtained = twelthPercentObtained;
	}

	public int getAdmissionFee() {
		return admissionFee;
	}

	public void setAdmissionFee(int admissionFee) {
		this.admissionFee = admissionFee;
	}

	public int getTutionFee() {
		return tutionFee;
	}

	public void setTutionFee(int tutionFee) {
		this.tutionFee = tutionFee;
	}

	public int getOtherFee() {
		return otherFee;
	}

	public void setOtherFee(int otherFee) {
		this.otherFee = otherFee;
	}

	public String getDisability() {
		return disability;
	}

	public void setDisability(String disability) {
		this.disability = disability;
	}

	public String getDisabilityType() {
		return disabilityType;
	}

	public void setDisabilityType(String disabilityType) {
		this.disabilityType = disabilityType;
	}

	public int getPercentOfDisability() {
		return percentOfDisability;
	}

	public void setPercentOfDisability(int percentOfDisability) {
		this.percentOfDisability = percentOfDisability;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getParentsProfession() {
		return parentsProfession;
	}

	public void setParentsProfession(String parentsProfession) {
		this.parentsProfession = parentsProfession;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getScheme() {
		return scheme;
	}

	public void setScheme(String scheme) {
		this.scheme = scheme;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDescriptionLevelOne() {
		return descriptionLevelOne;
	}

	public void setDescriptionLevelOne(String descriptionLevelOne) {
		this.descriptionLevelOne = descriptionLevelOne;
	}

	public String getDescriptionLevelTwo() {
		return descriptionLevelTwo;
	}

	public void setDescriptionLevelTwo(String descriptionLevelTwo) {
		this.descriptionLevelTwo = descriptionLevelTwo;
	}

	public String getDescriptionLevelThree() {
		return descriptionLevelThree;
	}

	public void setDescriptionLevelThree(String descriptionLevelThree) {
		this.descriptionLevelThree = descriptionLevelThree;
	}

	@Override
	public String toString() {
		return "Scholarship [applicationId=" + applicationId + ", aadhaarNumber=" + aadhaarNumber + ", religion="
				+ religion + ", community=" + community + ", fatherName=" + fatherName + ", motherName=" + motherName
				+ ", familyAnnualIncome=" + familyAnnualIncome + ", rationCardNumber=" + rationCardNumber
				+ ", instituteName=" + instituteName + ", presentCourse=" + presentCourse + ", presentClassYear="
				+ presentClassYear + ", modeOfStudy=" + modeOfStudy + ", classStartDate=" + classStartDate
				+ ", universityBoardName=" + universityBoardName + ", previousClassCourse=" + previousClassCourse
				+ ", previousPassingYear=" + previousPassingYear + ", previousClassPercent=" + previousClassPercent
				+ ", tenthRollNumber=" + tenthRollNumber + ", tenthBoardName=" + tenthBoardName + ", tenthPassingYear="
				+ tenthPassingYear + ", tenthPercentObtained=" + tenthPercentObtained + ", twelthRollNumber="
				+ twelthRollNumber + ", twelthBoardName=" + twelthBoardName + ", twelthPassingYear=" + twelthPassingYear
				+ ", twelthPercentObtained=" + twelthPercentObtained + ", admissionFee=" + admissionFee + ", tutionFee="
				+ tutionFee + ", otherFee=" + otherFee + ", disability=" + disability + ", disabilityType="
				+ disabilityType + ", percentOfDisability=" + percentOfDisability + ", maritalStatus=" + maritalStatus
				+ ", parentsProfession=" + parentsProfession + ", address=" + address + ", scheme=" + scheme
				+ ", status=" + status + ", descriptionLevelOne=" + descriptionLevelOne + ", descriptionLevelTwo="
				+ descriptionLevelTwo + ", descriptionLevelThree=" + descriptionLevelThree + "]";
	}

	

	
		


}

