package com.lnt.hr.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

// http://localhost:8082/Project_trial/app/home

@Controller("HomeController")
public class HomeController 
{
	@RequestMapping("/")
	public String directHomePage()
	{
		return "homePage";
	}
	

	@RequestMapping("/meritBasedScholarship")
	public String directmeritBasedScholarshipPage()
	{
		return "meritBasedScholarship";
	}
	
	
	@RequestMapping("/minorityBasedScholarship")
	public String directminorityBasedScholarshipPage()
	{
		return "minorityBasedScholarship";
	}
	

	
	@RequestMapping("/pragatiScholarshipForGirls")
	public String directpragatiScholarshipForGirlsPage()
	{
		return "pragatiScholarshipForGirls";
	}
	
	
	@RequestMapping("/aboutUs")
	public String aboutUs()
	{
		return "aboutUs";
	}

	@RequestMapping("/homePage")
	public String redirectHomePage()
	{
		return "homePage";
	}
}
