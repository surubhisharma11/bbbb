package com.lnt.hr.controllers;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.hr.entities.Scholarship;
import com.lnt.hr.exception.ScholarshipException;
import com.lnt.hr.services.ScholarshipService;

@Controller("StatusController")
public class StatusController 
{
	@Resource
	private ScholarshipService scholarshipService;
	
	//*********************setting status by institute************************

	@RequestMapping("/approveApplication/{applicationId}/{status}")
	public ModelAndView acceptScholarshipStatus(ModelAndView mv,@PathVariable("applicationId") int applicationId, @PathVariable("status") String status)
	{
		Scholarship scholarship = new Scholarship();
		try 
		{
			scholarship=scholarshipService.getApplDetails(applicationId);
			scholarship.setDescriptionLevelTwo(status);
			scholarshipService.setApplicationStatus(scholarship);

			System.out.println(scholarship);
		} 
		catch (ScholarshipException e)
		{
			e.printStackTrace();
		}
		
		mv.addObject("scholarshipDetails", scholarship);
		mv.setViewName("acceptedList");
		
	
	return mv;
		
	}
	
	//*********************setting status by minister************************

	@RequestMapping("/approveStudMinApplication/{applicationId}/{status}")
	public ModelAndView acceptMinistryScholarshipStatus(ModelAndView mv,@PathVariable("applicationId") int applicationId, @PathVariable("status") String status)
	{
		Scholarship scholarship = new Scholarship();
		try 
		{
			scholarship=scholarshipService.getApplDetails(applicationId);
			scholarship.setDescriptionLevelThree(status);
			scholarshipService.setApplicationStatus(scholarship);

			System.out.println(scholarship);
		} 
		catch (ScholarshipException e)
		{
			e.printStackTrace();
		}
		
		mv.addObject("scholarshipDetails", scholarship);
		mv.setViewName("minAcceptForm");
		
	
	return mv;
		
	}
	

}
