package com.lnt.hr.controllers;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.hr.eligibility.Builder;
import com.lnt.hr.eligibility.CheckEligibility;
import com.lnt.hr.eligibility.CheckPragatiEligibility;
import com.lnt.hr.entities.FileUploadForm;
import com.lnt.hr.entities.InstituteRegistration;
import com.lnt.hr.entities.Login;
import com.lnt.hr.entities.Registration;
import com.lnt.hr.entities.Scholarship;
import com.lnt.hr.exception.LoginException;
import com.lnt.hr.exception.RegistrationException;
import com.lnt.hr.exception.ScholarshipException;
import com.lnt.hr.services.InstituteRegistrationService;
import com.lnt.hr.services.LoginService;
import com.lnt.hr.services.RegistrationService;
import com.lnt.hr.services.RegistrationServiceImpl;
import com.lnt.hr.services.ScholarshipService;


@Controller("RegistrationController")
public class RegistrationController 
{
	@Resource
	private InstituteRegistrationService insServices;
	@Autowired
	ServletContext context;
	
	@Resource
	private RegistrationService services = new RegistrationServiceImpl();
	
	@Resource
	private ScholarshipService scholarshipService;
	
	@Resource
	private LoginService loginService;
	


	@Autowired(required=true)
	private WebApplicationContext ctx;
	//**************Student Registration************************

	
	@RequestMapping("/showRegistrationForm")
	public ModelAndView showRegistrationForm() {
		ModelAndView mv = new ModelAndView("regForm");
		Registration registration = new Registration();
		mv.addObject("registration", registration);
		return mv;
	}
	
	@RequestMapping("/submitForm")
	public ModelAndView joinNewStudent(@Valid @ModelAttribute("registration") Registration registration, BindingResult br,
			HttpServletRequest request) 
	{
		Login login=null;
		ModelAndView mv = new ModelAndView("disStuDetails");
		
		String password =request.getParameter("password");
		
			try 
			{
				registration = services.insertNewStudent(registration);
			//	String password= registration.getPassword();
				int loginId = (int) registration.getStudentId();
				login=loginService.insertNewStudent(new Login(loginId, password));
				mv.addObject("studentDetails", registration);
				//mv.addObject("studentDetails", registration);
				
			} 
			catch(LoginException e)
			{
				mv.setViewName("errorPage");
				return mv;
			}
			catch (RegistrationException e) 
			{	
				
				mv.setViewName("errorPage");
				return mv;
			}
			mv.addObject("message", "Succesfully added details");
			return mv;
		}
	
	@RequestMapping("/submitRegForm")
	public String submitRegForm()
	{
		return "successReg";
	}
	
	@RequestMapping("/submitScholarshipForm")
	public String submitScholarshipForm()
	{
		return "successScholarForm";
	}
	
	//**************Institute Registration************************
	
	@RequestMapping("/showInsRegistrationForm")
	public ModelAndView showInsRegistrationForm() {
		ModelAndView mv = new ModelAndView("InstituteRegistration");
		InstituteRegistration instituteRegistration = new InstituteRegistration();
		mv.addObject("instituteRegistration", instituteRegistration);
		return mv;
	}
	
	@RequestMapping("/submitInsForm")
	public ModelAndView joinNewCustomer(@Valid @ModelAttribute("instituteRegistration") InstituteRegistration instituteRegistration, BindingResult br,
			HttpServletRequest request, @ModelAttribute("files") FileUploadForm uploadForm, Model model) 
	{
		Login login=null;
		String password =request.getParameter("password");
		ModelAndView mv = new ModelAndView("disInsDetails");
		 //String uploadDirectory = "C:\\Users\\lntinfotech\\Desktop\\Workplace"+"/uploads";
			try 
			{
				//instituteRegistration.setYearFromAdmissionStarted(Date.valueOf(request.getParameter("yearFromAdmissionStarted")));
				
				instituteRegistration = insServices.insertNewInstitute(instituteRegistration);
				int loginId=(int) instituteRegistration.getInstituteCode();
				loginService.insertNewStudent(new Login(loginId, password));
				//System.out.println("testing 1");
				mv.addObject("instituteDetails", instituteRegistration);
			} 
			catch(LoginException e)
			{
				e.printStackTrace();
			}
			catch (RegistrationException e)
			{
				ModelAndView mv1 = new ModelAndView("errorPage");
				//System.out.println("testing 2");
				//mv.setViewName("errorPage");
				return mv1;
			}
			//System.out.println(instituteRegistration);
			String prefix=Long.toString(instituteRegistration.getInstituteCode());
			//System.out.println(prefix);
			List<MultipartFile> files = uploadForm.getFiles();
			List<String> fileNames = new ArrayList<String>();
			fileNames.add("EstProof.pdf");
			fileNames.add("UnivCert.pdf");
			

			if (null != files && files.size() > 0) {
				for (int i = 0; i < files.size(); i++) {
					MultipartFile file = files.get(i);
					
					String uploadPath = context.getRealPath("") + File.separator + "Uploaded Documents" + File.separator;
					System.out.println(uploadPath);
					try 
					{
						FileCopyUtils.copy(file.getBytes(), new File(uploadPath +prefix+ "_" + fileNames.get(i)));
					} 
					catch (IOException e)
					{
						mv.setViewName("errorPage");
						System.out.println(e);
						return mv;
					}
				}
			}
			
	  	
	  	  //model.addAttribute("msg", "Successfully uploaded files "+fileNames.toString());
			return mv;
		}
	
	
	
	@RequestMapping("/submitInsRegForm")
	public String submitInsRegForm()
	{
		return "successInsRegForm";
	}
	
	//**************Scholarship Registration************************
	
	@RequestMapping("/submitScholForm")
	public ModelAndView joinNewScholarship(@Valid @ModelAttribute("scholarshipForm") Scholarship scholarship, BindingResult br,
			HttpServletRequest request, @ModelAttribute("files") FileUploadForm uploadForm, Model model) 
	{
		
		String scheme = request.getParameter("scheme");
		ModelAndView mv = new ModelAndView("disScholDetails");
		scholarship.setDescriptionLevelOne("Approved");
		scholarship.setDescriptionLevelTwo("Pending");
		scholarship.setDescriptionLevelThree("Pending");
		
		Builder builder = ctx.getBean("Builder", Builder.class);
		CheckEligibility ce = builder.getEligibilityStrategy("MeritBased");
		
		CheckPragatiEligibility ce1= builder.getPragatiEligibilityStrategy("Pragati");
		

		String status = ce.checkEligibility(scholarship);
		
		Registration registration ;
		//String status1 = ce1.CheckPragatiEligibility(registration, scholarship); 
		//System.out.println(description);
		
		if((status.equals("true")))
		{
			//System.out.println("test  4");
		try 
			{
				scholarship = scholarshipService.insertNewScholarship(scholarship);
				mv.addObject("scholarshipDetails", scholarship);
			
			} 
			catch (ScholarshipException e) 
			{
				mv.addObject("message", "Failed to register. There appears to be an account with the entered details already.");
				mv.setViewName("errorPage");
				return mv;
			}
			//System.out.println(instituteRegistration);
			String prefix=Long.toString(scholarship.getApplicationId());
			//System.out.println(prefix);
			List<MultipartFile> files = uploadForm.getFiles();
			List<String> fileNames = new ArrayList<String>();
			fileNames.add("domCert.pdf");
			fileNames.add("stuPhoto.pdf");
			fileNames.add("idCard.pdf");
			fileNames.add("casteCertificate.pdf");
			fileNames.add("prevYearMarksheet.pdf");
			fileNames.add("feeReceipt.pdf");
			fileNames.add("bankPass.pdf");
			fileNames.add("aadharCard.pdf");
			fileNames.add("xMarksheet.pdf");
			fileNames.add("xiiMarksheet.pdf");
			if (null != files && files.size() > 0) {
				for (int i = 0; i < files.size(); i++) {
					MultipartFile file = files.get(i);
					
					String uploadPath = context.getRealPath("") + File.separator + "Uploaded Documents" + File.separator;
					try 
					{
						FileCopyUtils.copy(file.getBytes(), new File(uploadPath +prefix+ "_" + fileNames.get(i)));
					}
					catch (IOException e)
					{
						mv.setViewName("errorPage");
						return mv;
					}
				}
			}
			mv.addObject("message","Thank you for applying for the scholarship. Your application has been forwarded for futher verification.");
	
			
		}
		else
		{
			mv.addObject("message","Sorry, you are not found eligible for this scheme. Please try other schemes");
			return mv;
		}
	  	
	  	  //model.addAttribute("msg", "Successfully uploaded files "+fileNames.toString());
			return mv;
		}

	
}
