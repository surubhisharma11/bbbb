package com.lnt.hr.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.HibernateException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.hr.entities.InstituteRegistration;
import com.lnt.hr.exception.RegistrationException;
import com.lnt.hr.exception.ScholarshipException;

@Repository
@Transactional(propagation= Propagation.REQUIRED)
public class InstituteRegistrationDaoImpl implements InstituteRegistrationDao
{	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public InstituteRegistration insertNewInstitute(InstituteRegistration instituteRegistration) throws RegistrationException 
	{
		try
		{
			entityManager.persist(instituteRegistration);
			return instituteRegistration;
		}
		catch(Exception e)
		{
			throw new RegistrationException("OOP's!!! Something went wrong while inserting a new student", e);
		}
	}

	@Override
	public List<InstituteRegistration> getInsList() throws RegistrationException 
	{
		try
		{
			Query qry=entityManager.createNamedQuery("allInstitute");

			return qry.getResultList();
		}
		
		catch(Exception e)
		{
			throw new RegistrationException("OOP's!!! Something went wrong while inserting a new student", e);
		}
	}

	@Override
	public InstituteRegistration getInsDetails(long instituteCode) throws RegistrationException 
	{
		try
		{
			InstituteRegistration insDetails=entityManager.find(InstituteRegistration.class,instituteCode);
			return insDetails;
		}
		catch(Exception e)
		{
			throw new RegistrationException("OOP's!!! Something went wrong while inserting a new student", e);
		}
	}
	
	
	
	
	

}
